Xymon Client for z/VSE 1.2 Readme           

This file is used to collect hints and tips for the installation and use
of the client on z/VSE systems.
It will also provide between release fix information.

01/19/2010 - 
To track (graph) the number of jobs running in a specific class add a PROC string to hobbit-clients.cfg that is similar to this:

PROC "%^.*\b\bV\b.*" 0 10 Yellow TRACK=ClassV "TEXT=Class V jobs"

The text in the quotes after PROC is a regular expression that will look for V class jobs in the data returned from the VSE client in the [jobs] stanza.  Replace the V in the expression, and in the TRACK and TEXT text with the class in which you have interest.

01/27/2010 -
The CICS transaction count data is sent to Xymon as the number of transactions since the last client interval (the past 5 minutes).  The graph as shipped with the Xymon server is set up to graph the raw number of transactions in that fashion.  If a site desires to have the data graphed as transactions per minute or transactions per second, the graph definition will need to be altered.

On the Xymon server in $HOME/server/etc is a file called hobbitgraphs.cfg.  It contains all of the graph definitions.  In it is a section for the CICS transaction graph.  It looks like this:

[cics]
         FNPATTERN ^cics.(.+).rrd
         TITLE CICS Transaction Rate
         YAXIS Transactions
         DEF:nt@RRDIDX@=@RRDFN@:numtrans:AVERAGE
         LINE2:nt@RRDIDX@#@COLOR@:@RRDPARAM@
         GPRINT:nt@RRDIDX@:LAST: \: %5.1lf (cur)
         GPRINT:nt@RRDIDX@:MAX: \: %5.1lf (max)
         GPRINT:nt@RRDIDX@:MIN: \: %5.1lf (min)
         GPRINT:nt@RRDIDX@:AVERAGE: \: %5.1lf (avg)\n

To produce a graph that show transactions per minute replace that graph definition with this:

[cics]
         FNPATTERN ^cics.(.+).rrd
         TITLE CICS Transaction Rate
         YAXIS Transactions per Minute
         DEF:nt@RRDIDX@=@RRDFN@:numtrans:AVERAGE
	 CDEF:tpm@RRDIDX@=numtrans@RRDIDX@,5,/   Divide by 5 minute interval
         LINE2:tpm@RRDIDX@#@COLOR@:@RRDPARAM@
         GPRINT:tpm@RRDIDX@:LAST: \: %5.1lf (cur)
         GPRINT:tpm@RRDIDX@:MAX: \: %5.1lf (max)
         GPRINT:tpm@RRDIDX@:MIN: \: %5.1lf (min)
         GPRINT:tpm@RRDIDX@:AVERAGE: \: %5.1lf (avg)\n

To produce a graph that show transactions per second replace the original graph definition with this:

[cics]
         FNPATTERN ^cics.(.+).rrd
         TITLE CICS Transaction Rate
         YAXIS Transactions per Second
         DEF:nt@RRDIDX@=@RRDFN@:numtrans:AVERAGE
         CDEF:tps@RRDIDX@=numtrans@RRDIDX@,300,/ Divide by 300 second interval
         LINE2:tps@RRDIDX@#@COLOR@:@RRDPARAM@
         GPRINT:tps@RRDIDX@:LAST: \: %5.1lf (cur)
         GPRINT:tps@RRDIDX@:MAX: \: %5.1lf (max)
         GPRINT:tps@RRDIDX@:MIN: \: %5.1lf (min)
         GPRINT:tps@RRDIDX@:AVERAGE: \: %5.1lf (avg)\n



