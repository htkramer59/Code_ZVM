Xymon Client for z/VM 1.3 Readme

This file is used to collect hints and tips for the installation and use
of the client on z/VM systems.  
It will also provide between release fix information.

05/06/2009 -
Integrated fix for HOBVMDSK EXEC sent by Pat Carroll of LL Bean for handling of large CP disk areas.

07/08/2009 -
Fix contributed by Frank Ramarkers of AILife to HOBVMDSK EXEC for handling alerts on minidisk thresholds.

08/26/2009 -
Resolved issue of client not handling standalone DUMP volume properly.
(Martha McConaghy - Marist University)

Changed HOBVMCPU to write out data via a pipeline to resolve a problem with
data left on the stack.

08/28/2009 - 
Added variable to indicate the default name of the z/VM TCP/IP stack.
(Martha McConaghy - Marist University)

If there is no desire to use the SFS file pool tests, set the DISK variable
to NULL (DISK='') in HOBVARS.

09/03/2009 -
With the Xymon server running as a virtual machine on z/VM intermittent 
notifications (and recovery messages, if configured) will be sent out under 
heavy z/VM system load.  The solution is to set the SHARE of the Xymon server 
virtual machine to a higher value.
(Martha McConaghy - Marist University)

